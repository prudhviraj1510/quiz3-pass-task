#!/usr/bin/env python
import rospy
import math
import sys
from time import sleep
import tf

import tf2_ros
import tf2_msgs.msg
import tf_conversions

from tf2_sensor_msgs.tf2_sensor_msgs import do_transform_cloud
from sensor_msgs.msg import PointCloud2
import std_msgs.msg
from std_msgs.msg import UInt16
import sensor_msgs.point_cloud2 as pcl2
import geometry_msgs.msg

wall_left, wall_front, wall_right = 0, 0, 0

transx, transy, transz = 0, 0, 0
rotx, roty, rotz, rotw = 0, 0, 0, 0

def publish_walls():

        #build the point cloud imagining we are at 0,0,0.
        cloud_points = []   #distance, X and Y
        if(wall_left>0): cloud_points.append([(wall_left-2)/3, 1.5, 0.5])
        if(wall_front>0): cloud_points.append([wall_front/10, 0, 0])
        if(wall_right>0): cloud_points.append([(wall_right-2)/3, -1.5, 0.5])

        header = std_msgs.msg.Header()
        header.stamp = rospy.Time.now()
        header.frame_id = 'odom'
        mypointcloud = pcl2.create_cloud_xyz32(header, cloud_points)

        #We need to build a transformation of our location.
        t = geometry_msgs.msg.TransformStamped()
        t.header.stamp = rospy.Time.now()
        t.header.frame_id = "odom"
        t.child_frame_id = "base_link"
        t.transform.translation.x = transx
        t.transform.translation.y = transy
        t.transform.translation.z = transz
        t.transform.rotation.x = rotx
        t.transform.rotation.y = roty
        t.transform.rotation.z = rotz
        t.transform.rotation.w = rotw

        #convert the pointcloud to take into account our location.
        cloud_out = do_transform_cloud(mypointcloud, t)
        pcl_pub.publish(cloud_out)

def handle_zumo_left(wall_msg):
        global wall_left
        wall_left = wall_msg.data
        publish_walls()

def handle_zumo_front(wall_msg):
        global wall_front
        wall_front = wall_msg.data
        publish_walls()

def handle_zumo_right(wall_msg):
        global wall_right
        wall_right = wall_msg.data
        publish_walls()

if __name__ == '__main__':
        pcl_pub = rospy.Publisher("/zumo/objectcloud", PointCloud2, queue_size=10)
        rospy.init_node('objectdetect_node')
        listener = tf.TransformListener()
        rospy.sleep(1.)
        rospy.Subscriber('/zumo/left', UInt16, handle_zumo_left)
        rospy.Subscriber('/zumo/front', UInt16, handle_zumo_front)
        rospy.Subscriber('/zumo/right', UInt16, handle_zumo_right)
        rate = rospy.Rate(10.0)
        while not rospy.is_shutdown():
                try:
                        (trans,rot) = listener.lookupTransform('/odom', '/base_link', rospy.Time(0))
                except (tf.LookupException, tf.ConnectivityException, tf.ExtrapolationException):
                        continue
                transx = trans[0]
                transy = trans[1]
                transz = trans[2]
                rotx = rot[0]
                roty = rot[1]
                rotz = rot[2]
                rotw = rot[3]
        rospy.spin()
